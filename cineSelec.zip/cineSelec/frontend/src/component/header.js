import React from 'react'
import { NavLink } from 'react-router-dom';
const Header = () => {
    return (
        <>
            <nav className="navbar">
                <div className='container-fluid hr'>
                    <div className='navbar-brand ms-5 mb-3'>
                        <NavLink
                            className="navbar-brand"
                            activeClassName="active"
                            exact
                            to="/">CINESELECT</NavLink>
                        <img src="/logo (9).png" alt="logo" className='logo' />
                    </div>
                    <ul className='navbar-nav flex-row mx-3 '>
                        <li className="nav-item mx-3">
                            <NavLink
                                className="nav-link"
                                activeClassName="active"
                                exact
                                to="/home">HOME</NavLink>
                        </li>
                        <li className="nav-item ">
                            <NavLink
                                className="nav-link"
                            >|</NavLink>
                        </li>


                        <li className="nav-item mx-3">
                            <NavLink
                                className="nav-link"
                                activeClassName="active"
                                to="/about">ABOUT</NavLink>
                        </li>
                        <li className="nav-item ">
                            <NavLink
                                className="nav-link"
                            >|</NavLink>
                        </li>
                        <li className="nav-item mx-3  mb-3">
                            <NavLink
                                className="nav-link"
                                activeClassName="active"
                                to="/find-blood"> CONTACT US</NavLink>
                        </li>

                    </ul>

                </div>
            </nav>

        </>
    )
}

export default Header