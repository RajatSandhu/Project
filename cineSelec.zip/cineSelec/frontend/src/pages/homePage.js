import React from 'react'

const HomePage = () => {
    return (
        <div>H</div>
    )
}

export default HomePage