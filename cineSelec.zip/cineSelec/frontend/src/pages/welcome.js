import React from 'react'
import Header from '../component/header';

const Welcome = () => {
    return (
        <>

            <div className='container-flued bg-dark  g-0 text-center' style={{ height: "100vh" }}>
                <Header />
                <h1 className='mt-5 fs-1 fw-bolder'>WELCOME!</h1>
                <p className='mt-4 fs-4'>Hey folks! You can’t decide between thousands of movies available for streaming?</p>
                <p className='mt-2 fs-4'>Here’s the answer</p>

                <div class="d-grid gap-5  col-9 mx-auto mt-5">
                    <button class="btn btn-danger rounded-pill fs-3 fw-normal" type="button">Get Started</button>

                </div>
            </div>
        </>
    )
}

export default Welcome;