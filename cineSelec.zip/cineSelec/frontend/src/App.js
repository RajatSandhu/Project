
import './App.css';
import { Routes, Route } from 'react-router-dom';
import Welcome from './pages/welcome';
import HomePage from './pages/homePage';
function App() {
  return (
    <>
      <Routes>
        <Route path="/" element={<Welcome />} />
        <Route path="/home" element={<HomePage />} />
      </Routes>
    </>
  );
}

export default App;
